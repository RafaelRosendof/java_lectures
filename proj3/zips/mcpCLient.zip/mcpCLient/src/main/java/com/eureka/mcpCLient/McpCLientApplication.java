package com.eureka.mcpCLient;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class McpCLientApplication {

	public static void main(String[] args) {
		SpringApplication.run(McpCLientApplication.class, args);
	}

}
