package com.eureka.mcpServer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class McpServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
