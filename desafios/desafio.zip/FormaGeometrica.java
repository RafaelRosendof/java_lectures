public abstract class FormaGeometrica{
  
  abstract float calcula_area();
}
