public class SemArgsException extends Exception {
   public SemArgsException(String mess){
    super(mess);
   } 
}
